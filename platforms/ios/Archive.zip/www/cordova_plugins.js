cordova.define('cordova/plugin_list', function(require, exports, module) {
module.exports = [
    {
        "file": "plugins/edu.cornell.stepometer/www/stepometer.js",
        "id": "edu.cornell.stepometer.Stepometer"
    }
];
module.exports.metadata = 
// TOP OF METADATA
{
    "org.apache.cordova.device-motion": "0.2.10",
    "edu.cornell.stepometer": "0.2.10"
}
// BOTTOM OF METADATA
});